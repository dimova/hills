package com.xdesign.munrotable.dto;

public enum SortOrder {
    ASC,
    DESC
}
