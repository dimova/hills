package com.xdesign.munrotable.exception;

public final class CsvFileLoadingException extends RuntimeException {

    public CsvFileLoadingException(Throwable cause) {
        super(cause);
    }
}
